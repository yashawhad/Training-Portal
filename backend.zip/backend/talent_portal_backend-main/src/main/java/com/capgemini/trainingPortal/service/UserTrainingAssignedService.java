package com.capgemini.trainingPortal.service;

public interface UserTrainingAssignedService {

	void assignTraining(Long userId, Long trainingId);

}
